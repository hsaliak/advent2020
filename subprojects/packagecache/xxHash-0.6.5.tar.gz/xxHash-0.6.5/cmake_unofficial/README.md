

The `cmake` script present in this directory offers the following options :

- `BUILD_XXHSUM` : build the command line binary. ON by default
- `BUILD_SHARED_LIBS` : build dynamic library. ON by default.
